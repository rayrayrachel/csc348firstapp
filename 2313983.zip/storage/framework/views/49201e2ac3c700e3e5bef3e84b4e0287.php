<div>

    <h2><?php echo e($bloggerProfile->user_name); ?> <?php echo e(__('\'s Information')); ?></h2>


    <div class="blogger-information-profile-container">
        <div class="blogger-information-profile-picture-container">
            <!--[if BLOCK]><![endif]--><?php if($bloggerProfile->profile_picture): ?>
                <img src="<?php echo e(asset('storage/' . $bloggerProfile->profile_picture)); ?>"
                    alt="Profile picture of <?php echo e($bloggerProfile->user_name); ?>" class="blogger-information-profile-picture">
            <?php else: ?>
                <img src="<?php echo e(asset('images/default-pfp.gif')); ?>" alt="Default profile image"
                    class="blogger-information-profile-picture">
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="blogger-information-text-container  space-y-2">
            <p><strong><?php echo e(__('Bio:')); ?></strong> <?php echo e($bloggerProfile->bio ?? 'No bio provided'); ?></p>
            <p><strong><?php echo e(__('Website:')); ?></strong>
                <!--[if BLOCK]><![endif]--><?php if($bloggerProfile->website): ?>
                    <a href="<?php echo e($bloggerProfile->website); ?>" target="_blank" class="text-blue-500">
                        <?php echo e($bloggerProfile->website); ?>

                    </a>
                <?php else: ?>
                    <?php echo e('Not provided'); ?>

                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </p>
            <p><strong><?php echo e(__('Location:')); ?></strong> <?php echo e($bloggerProfile->location ?? 'Not provided'); ?></p>

            <!--[if BLOCK]><![endif]--><?php if($bloggerProfile->date_of_birth): ?>
                <p><strong><?php echo e(__('Date of Birth:')); ?></strong> <?php echo e($bloggerProfile->date_of_birth ?? 'Not provided'); ?>

                    <strong><?php echo e(__('Age:')); ?></strong>
                    <?php echo e(\Carbon\Carbon::parse($bloggerProfile->date_of_birth)->age); ?> <?php echo e(__('years old')); ?>

                </p>
            <?php else: ?>
                <p>
                    <strong><?php echo e(__('Date of Birth:')); ?></strong> <?php echo e($bloggerProfile->date_of_birth ?? 'Not provided'); ?>

                </p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <p><strong><?php echo e(__('Account Created:')); ?></strong>
                <?php echo e($bloggerProfile->created_at->diffForHumans() ?? 'Not provided'); ?></p>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/livewire/display-blogger-profile.blade.php ENDPATH**/ ?>