<!DOCTYPE html>
<html>
<head>
    <title>New Comment</title>
</head>
<body>
    <h2><?php echo e($commenter->name); ?> commented on your project: <strong><?php echo e($project->title); ?></strong></h2>
    <p>Your project: <strong><?php echo e($project->title); ?></strong></p>
    <p>Comment: "<?php echo e($comment->content); ?>"</p>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/emails/comment-notification.blade.php ENDPATH**/ ?>