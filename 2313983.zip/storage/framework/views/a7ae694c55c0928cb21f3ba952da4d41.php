<div class="blogger-name-container">
    <a href="<?php echo e(route('bloggers.profile', $blogger->id)); ?>">
        <div class="pfp">
            <div class="pfp-container">
                <!--[if BLOCK]><![endif]--><?php if($blogger->bloggerProfile && $blogger->bloggerProfile->profile_picture): ?>
                    <img src="<?php echo e(asset('storage/' . $blogger->bloggerProfile->profile_picture)); ?>"
                        alt="<?php echo e($blogger->name); ?>'s Profile Picture" class="pfp-container">
                <?php else: ?>
                    <img src="<?php echo e(asset('images/default-pfp.gif')); ?>" alt="Default Profile Picture" class="pfp-container">
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <div class="blogger-details">
            <h2 class="blogger-name"><?php echo e($blogger->bloggerProfile->user_name ?? $blogger->name); ?></h2>
        </div>
    </a>
</div>
<?php /**PATH /var/www/html/resources/views/livewire/blogger-p-f-p.blade.php ENDPATH**/ ?>