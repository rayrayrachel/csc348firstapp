

            <!-- Display Profile Information -->
            <section>
                <header>
                    <h3 class="text-lg font-medium text-gray-900"><?php echo e(__('Blogger Profile Information')); ?></h3>
                </header>
    
            </br>
                    <div class="space-y-4">
                        <p><strong><?php echo e(__('Bio:')); ?></strong> <?php echo e($bloggerProfile->bio ?? 'No bio provided'); ?></p>
                        <p><strong><?php echo e(__('Website:')); ?></strong> 
                            <a href="<?php echo e($bloggerProfile->website ?? 'Not provided'); ?>" target="_blank" class="text-blue-500">
                                <?php echo e($bloggerProfile->website ?? 'Not provided'); ?>

                            </a>
                        </p>
                        <p><strong><?php echo e(__('Location:')); ?></strong> <?php echo e($bloggerProfile->location ?? 'Not provided'); ?></p>
                        <p><strong><?php echo e(__('Date of Birth:')); ?></strong> <?php echo e($bloggerProfile->date_of_birth ?? 'Not provided'); ?></p>
                        <p><strong><?php echo e(__('Account Created:')); ?></strong> <?php echo e($bloggerProfile->created_at ?? 'Not provided'); ?></p>
                    </div>

                </br>
            </section>


  <?php /**PATH /var/www/html/resources/views/profile/partials/display-blogger-form.blade.php ENDPATH**/ ?>