<div>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="page-header">
            <?php echo e(__('Project Details')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="page-container">

        <div class="element-container" id="projectDetailsContainer">

            <div class="flex justify-between items-center">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('blogger-p-f-p', ['userId' => $project->user->id]);

$__html = app('livewire')->mount($__name, $__params, 'blogger-p-f-p-' . $project->user->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

                <!--[if BLOCK]><![endif]--><?php if(auth()->guard()->check()): ?>
                    <!--[if BLOCK]><![endif]--><?php if(Auth::id() === $project->user_id || Auth::user()->role === 'admin'): ?>
                        <a href="<?php echo e(route('projects.edit', $project->id)); ?>">
                            <button class="submit-btn">
                                EDIT PROJECT
                            </button>
                        </a>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            </div>
            <div class="flex justify-between items-center overflow-hidden">
                <h2 class="truncate max-w-[calc(100%-100px)]"><?php echo e($project->title); ?></h2>
                <div class="flex">
                    <!--[if BLOCK]><![endif]--><?php if($project->status): ?>
                        <div class="project-status bg-gray-200 text-sm text-white px-3 py-1 rounded">
                            <?php echo e($project->status); ?>

                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <div class="px-3">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('like-button', ['likeable' => $project]);

$__html = app('livewire')->mount($__name, $__params, 'like-button-' . $project->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
            </div>
            <div>
                <!--[if BLOCK]><![endif]--><?php if($project->categories->isNotEmpty()): ?>
                    <div class="py-3"> Project Categories:
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $project->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="category"><?php echo e($category->name); ?></span>
                            <!--[if BLOCK]><![endif]--><?php if(!$loop->last): ?>
                                <span> </span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div class="overflow-hidden">
                <p><?php echo e($project->description); ?></p>
            </div>

            <!--[if BLOCK]><![endif]--><?php if($project->featureimage): ?>
                <img src="<?php echo e(asset('storage/' . $project->featureimage)); ?>"
                    alt="Feature image of <?php echo e($project->title); ?>">
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($project->methodology_used): ?>
                <p class="text-description">Methodology Used: <?php echo e($project->methodology_used); ?></p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <p class="timestamp"><strong> Created At: </strong><?php echo e($project->created_at->diffForHumans()); ?>

                <strong>Updated At: </strong><?php echo e($project->updated_at->diffForHumans()); ?>

            </p>

            <!--[if BLOCK]><![endif]--><?php if($project->project_link): ?>
                <p class="link">External Link To This Project:
                    <a href="<?php echo e($project->project_link); ?>" target="_blank">
                        <?php echo e($project->project_link); ?>

                    </a>
                </p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($embedUrl): ?>
                <div class="youtube-video mt-4">
                    <iframe width="560" height="315" src="<?php echo e($embedUrl); ?>" title="YouTube video player"
                        frameborder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowfullscreen>
                    </iframe>
                </div>
            <?php else: ?>
                <p class="text-gray-500 mt-4">No valid YouTube video to display.</p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        </div>

        <div class="element-container">

            <div class="flex justify-between items-center">
                <h2><?php echo e(__('Comments')); ?></h2>

                <!--[if BLOCK]><![endif]--><?php if(auth()->guard()->check()): ?>
                    <button id="toggleCommentButton" onclick="toggleCreateCommentForm()"
                        class="bg-[#36c73b] text-white py-2 px-4 rounded">
                        Add Comment
                    </button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            </div>

            <div class="flex">
                <div id="commentList" class="w-full transition-all" wire:key="comments-display-<?php echo e($project->id); ?>">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('comments-display', ['projectId' => $project->id]);

$__html = app('livewire')->mount($__name, $__params, 'comments-display-' . $project->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>

                <div id="createCommentForm" class="w-1/3 h-max hidden transition-all"
                    wire:key="create-comment-<?php echo e($project->id); ?>">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('create-comment', ['projectId' => $project->id]);

$__html = app('livewire')->mount($__name, $__params, 'create-comment-' . $project->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function toggleCreateCommentForm() {
        const form = document.getElementById("createCommentForm");
        const button = document.getElementById("toggleCommentButton");
        const commentList = document.getElementById("commentList");
        const commentsContainer = document.getElementById("commentsContainer");

        if (form.style.display === "none" || form.style.display === "") {
            form.style.display = "block";
            button.textContent = "Close Comment Form";
            commentList.classList.add("lg:w-2/3");
            button.classList.remove("bg-[#36c73b]");
            button.classList.add("bg-gray-300");
        } else {
            form.style.display = "none";
            button.textContent = "Add Comment";
            commentList.classList.remove("lg:w-2/3");
            button.classList.remove("bg-gray-300");
            button.classList.add("bg-[#36c73b]");
        }
    }
</script>
<?php /**PATH /var/www/html/resources/views/livewire/project-details.blade.php ENDPATH**/ ?>