<div>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="page-header">
            <?php echo e(__('Blogger Profile')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="page-container">
        <div class="element-container">
            <form wire:submit.prevent="save" enctype="multipart/form-data">
                <div>

                    <div class="update-blogger-information-profile-picture-container ">
                        <!--[if BLOCK]><![endif]--><?php if($bloggerProfile->profile_picture): ?>
                            <img src="<?php echo e(asset('storage/' . $bloggerProfile->profile_picture)); ?>"
                                alt="Profile picture of <?php echo e(Auth::user()->name); ?>"
                                class="update-blogger-information-profile-picture">
                        <?php else: ?>
                            <img src="<?php echo e(asset('images/default-pfp.gif')); ?>" alt="Default profile image"
                                class="update-blogger-information-profile-picture">
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <!--[if BLOCK]><![endif]--><?php if($profile_picture): ?>
                        <div>
                            <label>Preview:</label>
                            <img src="<?php echo e($profile_picture->temporaryUrl()); ?>" alt="Image Preview"
                                style="max-width: 100%; height: auto; border: 1px solid #ccc;" />
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <div class="form-group">
                        <label for="profile_picture">Change Profile Picture</label>
                        <input type="file" wire:model="profile_picture" id="profile_picture">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['profile_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>


                    <div class="form-group">
                        <label for="bio"><?php echo e(__('Bio:')); ?></label>
                        <textarea wire:model="bio" id="bio" class="w-full"><?php echo e($bio); ?></textarea>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>


                    <div class="form-group">
                        <label for="website"><?php echo e(__('Website:')); ?></label>
                        <input type="url" wire:model="website" id="website" class="w-full"
                            value="<?php echo e($website); ?>">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>


                    <div class="form-group">
                        <label for="location"><?php echo e(__('Location:')); ?></label>
                        <input type="text" wire:model="location" id="location" class="w-full"
                            value="<?php echo e($location); ?>">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>


                    <div class="form-group">
                        <label for="date_of_birth"><?php echo e(__('Date of Birth:')); ?></label>
                        <input type="date" wire:model="date_of_birth" id="date_of_birth" class="w-full"
                            value="<?php echo e($date_of_birth); ?>">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-red-500"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <button type="submit" class="submit-btn"><?php echo e(__('Save Changes')); ?></button>
                </div>
            </form>

            <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                <div class="alert alert-success mt-4"><?php echo e(session('message')); ?></div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

</div>
<?php /**PATH /var/www/html/resources/views/livewire/blogger-profile-form.blade.php ENDPATH**/ ?>