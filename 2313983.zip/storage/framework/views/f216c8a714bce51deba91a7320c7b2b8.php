<div wire:poll>
    <!--[if BLOCK]><![endif]--><?php if(auth()->guard()->check()): ?>
        <button wire:click="toggleLike"
            class="flex items-center space-x-2 text-lg <?php echo e($isLiked ? 'text-red-500' : 'text-gray-500'); ?> hover:text-red-700">
            <i class="fas fa-heart"></i>
            <span><?php echo e($likeCount); ?></span>
        </button>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if(auth()->guard()->guest()): ?>
    <div class="flex items-center space-x-2 text-lg">
        <i class="fas fa-heart"></i>
        <span><?php echo e($likeCount); ?></span>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH /var/www/html/resources/views/livewire/like-button.blade.php ENDPATH**/ ?>