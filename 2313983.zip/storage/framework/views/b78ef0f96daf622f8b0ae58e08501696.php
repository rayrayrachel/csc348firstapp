<!DOCTYPE html>
<html>
<head>
    <title>New Like Notification</title>
</head>
<body>
    <h1>You received a new like!</h1>

    <p>Hello <?php echo e($likeable->user->name); ?>,</p>

    <?php if($likeable instanceof \App\Models\Post): ?>
        <p>Your post titled "<strong><?php echo e($likeable->title); ?></strong>" just received a new like!</p>
    <?php elseif($likeable instanceof \App\Models\Comment): ?>
        <p>Your comment on the post "<strong><?php echo e($likeable->project->title); ?></strong>" just received a new like!</p>
    <?php endif; ?>

    <p><strong><?php echo e($liker->name); ?></strong> liked it!</p>
    <p>Thanks,</p>
    <p>The Team</p>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/emails/like-notification.blade.php ENDPATH**/ ?>