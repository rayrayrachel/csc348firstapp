<div wire:poll>
    <!--[if BLOCK]><![endif]--><?php if($comments->isEmpty()): ?>
        <p>No comments yet.</p>
    <?php else: ?>
        <div>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="comment-container">
                    <a href="<?php echo e(route('bloggers.profile', $comment->user->id)); ?>">
                        <div class="comment-pfp">
                            <div class="comment-profile-picture-container">
                                <!--[if BLOCK]><![endif]--><?php if($comment->user->bloggerProfile->profile_picture): ?>
                                    <img src="<?php echo e(asset('storage/' . $comment->user->bloggerProfile->profile_picture)); ?>"
                                        alt="Profile picture of <?php echo e($comment->user->bloggerProfile->user_name); ?>"
                                        class="profile-picture">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('images/default-pfp.gif')); ?>" alt="Default project image"
                                        class="profile-picture">
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </a>

                    <div class="comment-text">
                        <p>
                            <a href="<?php echo e(route('bloggers.profile', $comment->user->id)); ?>">
                                <strong><?php echo e($comment->user->name); ?></strong>
                            </a>
                            says on project:
                            <a href="<?php echo e(route('project.details', $comment->project->id)); ?>">
                                <strong><?php echo e($comment->project->title); ?></strong>
                            </a>
                        </p>
                        <p><?php echo e($comment->content); ?></p>
                        <small class="text-gray-500"><?php echo e($comment->created_at->diffForHumans()); ?></small>

                        <!--[if BLOCK]><![endif]--><?php if(auth()->guard()->check()): ?>
                            <!--[if BLOCK]><![endif]--><?php if($editingCommentId === $comment->id): ?>
                                <div wire:key="comment-<?php echo e($comment->id); ?>">
                                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('edit-comment', ['comment' => $comment]);

$__html = app('livewire')->mount($__name, $__params, 'edit-comment-' . $comment->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            <!--[if BLOCK]><![endif]--><?php if($confirmingDelete === $comment->id): ?>
                                <div class="py-2">
                                    <p class="bg-red-500 py-2">Are you sure you want to delete this comment?</p>
                                    <div class="py-2">
                                        <button wire:click="deleteComment(<?php echo e($comment->id); ?>)"
                                            class="delete-button bg-red-500 text-white">
                                            Yes
                                        </button>
                                        <button wire:click="$set('confirmingDelete', null)"
                                            class="cancel-button bg-gray-500 text-white">
                                            No
                                        </button>
                                    </div>
                                </div>
                            <?php else: ?>
                                <!--[if BLOCK]><![endif]--><?php if(Auth::id() == $comment->user_id || Auth::user()->role === 'admin'): ?>
                                    <button wire:click="confirmDelete(<?php echo e($comment->id); ?>)"
                                        class="delete-button bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">
                                        DELETE
                                    </button>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>


                    <div class="px-3">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('like-button', ['likeable' => $comment]);

$__html = app('livewire')->mount($__name, $__params, 'like-button-' . $comment->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

                        <!--[if BLOCK]><![endif]--><?php if(auth()->guard()->check()): ?>
                            <!--[if BLOCK]><![endif]--><?php if(Auth::id() == $comment->user_id || Auth::user()->role === 'admin'): ?>
                                <div class="goto">
                                    <button wire:click="toggleEditForm(<?php echo e($comment->id); ?>)"
                                        class="edit-button <?php echo e($editingCommentId === $comment->id ? 'btn-danger' : 'edit-button-toggle'); ?>">
                                        <?php echo e($editingCommentId === $comment->id ? 'QUIT' : 'EDIT'); ?>

                                    </button>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

        </div>
        <div class="pagination">
            <?php echo e($comments->links()); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>

<script>
    window.addEventListener('confirmClicked', event => {
        location.reload();
    });
</script>
<?php /**PATH /var/www/html/resources/views/livewire/comments-display.blade.php ENDPATH**/ ?>