<div>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="page-header">
            <?php echo e(__('All Projects')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="page-container">
        <div class="element-container">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('project-list', ['context' => 'all-projects']);

$__html = app('livewire')->mount($__name, $__params, 'lw-3390047751-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>

</div>
<?php /**PATH /var/www/html/resources/views/livewire/projects.blade.php ENDPATH**/ ?>