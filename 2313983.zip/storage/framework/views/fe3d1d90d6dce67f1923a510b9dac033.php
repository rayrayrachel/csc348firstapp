<div >
    <form wire:submit.prevent="updateComment">
        <textarea wire:model="content" rows="1" class="form-control"><?php echo e($content); ?></textarea>
        <button type="submit" class="update-comment-button ">Update Comment</button>
    </form>
</div>
<?php /**PATH /var/www/html/resources/views/livewire/edit-comment.blade.php ENDPATH**/ ?>