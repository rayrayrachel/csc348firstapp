<div>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="page-header">
            <?php echo e(__('Blogger Profiles')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="page-container">
        <div class="element-container">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $bloggers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex justify-between">
                    <div class="flex-1">
                        <a href="<?php echo e(route('bloggers.profile', $blogger->id)); ?>" class="block">
                            <div class="blogger-card">
                                <div class="blogger-content">
                                    <div class="profile-picture-container">
                                        <!--[if BLOCK]><![endif]--><?php if($blogger->profile_picture): ?>
                                            <img src="<?php echo e(asset('storage/' . $blogger->profile_picture)); ?>"
                                                alt="Profile picture of <?php echo e($blogger->user_name); ?>"
                                                class="profile-picture">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('images/default-pfp.gif')); ?>" alt="Default project image"
                                                class="profile-picture">
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div class="blogger-list-text-container">

                                        <h3 class="blogger-name"> <?php echo e($blogger->user_name); ?> </h3>
                                        <p class="blogger-info"> <?php echo e($blogger->bio); ?> </p>
                                        <p class="blogger-info"> <?php echo e($blogger->location); ?> </p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>


                    <div class="flex items-center">
                        <!--[if BLOCK]><![endif]--><?php if(auth()->guard()->check()): ?>
                            <div>
                                <!--[if BLOCK]><![endif]--><?php if(auth()->user()->role === 'admin' && auth()->id() !== $blogger->user->id && $blogger->user->id !== 1): ?>
                                    <div class="admin-actions">
                                        <button wire:click="toggleUserRole(<?php echo e($blogger->user->id); ?>)"
                                            class="btn btn-toggle-role <?php echo e($blogger->user->role == 'admin' ? 'bg-red-500' : 'bg-green-500'); ?>">
                                            <?php echo e($blogger->user->role == 'admin' ? 'REMOVE ADMIN' : 'MAKE ADMIN'); ?>

                                        </button>
                                    </div>

                                    <?php elseif(auth()->user()->role === 'admin' ): ?>
                                    <div class="admin-actions">
                                        <div class="text-red-500 w-100">Forbidden</div>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

            <div class="pagination">
                <?php echo e($bloggers->links()); ?>

            </div>
        </div>
    </div>

</div>
<?php /**PATH /var/www/html/resources/views/livewire/blogger-list.blade.php ENDPATH**/ ?>