<div wire:ignore>
    
</div>
<?php /**PATH /var/www/html/resources/views/livewire/background-music.blade.php ENDPATH**/ ?>