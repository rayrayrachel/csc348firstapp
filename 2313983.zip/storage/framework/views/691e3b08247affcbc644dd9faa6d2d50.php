    <div>
        <form wire:submit.prevent="createProject">

            <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <div class="form-group">
                <label for="title">Title <span class="text-red-500">*</span></label>
                <input type="text" id="title" wire:model="title" placeholder="Enter project title" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div class="form-group">
                <label for="description">Description <span class="text-red-500">*</span></label>
                <textarea id="description" wire:model="description" placeholder="Enter project description"></textarea>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" wire:model="status" class="form-select" placeholder="Select project status">
                    <option value="">Select Status</option>
                    <option value="ongoing">Ongoing</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                </select>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>


            <div class="form-group">
                <label for="categories">Categories</label>
                <div class="flex space-x-4 items-center">
                    <select id="categories" wire:model="selectedCategory"
                        class="form-select w-full border-gray-300 rounded">
                        <option value="">Select a Category</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>

                    <button type="button" wire:click="addCategory" class="px-4 py-2 bg-blue-500 text-white rounded">
                        Add
                    </button>
                </div>

                <div class="mt-4">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="inline-flex items-center bg-gray-200 text-gray-700 rounded px-3 py-1 mb-2 mr-2">
                            <?php echo e($name); ?>

                            <button type="button" wire:click="removeCategory(<?php echo e($id); ?>)"
                                class="ml-2 text-red-500 font-bold">
                                &times;
                            </button>
                        </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>

            <div class="form-group">
                <label for="featureimage">Featured Image</label>
                <input type="file" id="featureimage" wire:model="featureimage" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['featureimage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                <!--[if BLOCK]><![endif]--><?php if($featureimage): ?>
                    <div>
                        <label>Preview:</label>
                        <img src="<?php echo e($featureimage->temporaryUrl()); ?>" alt="Image Preview"
                            style="max-width: 100%; height: auto; border: 1px solid #ccc;" />
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div class="form-group">
                <label for="methodology_used">Methodology Used</label>
                <input type="text" id="methodology_used" wire:model="methodology_used"
                    placeholder="Methodology used" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['methodology_used'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <div class="form-group">
                <label for="project_link">Project Link</label>
                <input type="url" id="project_link" wire:model="project_link" placeholder="Enter project link" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['project_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <button type="submit" class="submit-btn">Create Project</button>
        </form>
    </div>
<?php /**PATH /var/www/html/resources/views/livewire/create-project.blade.php ENDPATH**/ ?>