


<img src="<?php echo e(asset('images/Tree.png')); ?>" alt="App Logo" class="logo" >
<?php /**PATH /var/www/html/resources/views/components/application-logo.blade.php ENDPATH**/ ?>