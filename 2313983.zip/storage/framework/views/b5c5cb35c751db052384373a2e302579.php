<div>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="page-header">
            <?php echo e($profile->user_name); ?> <?php echo e(__('\'s Blog')); ?>

        </h2>
     <?php $__env->endSlot(); ?>


    <div class="page-container">
        <div class="blogger-profile">

            <div class="element-container">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('display-blogger-profile', ['userId' => $profile->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3475104340-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>

            <div class="element-container">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('statistics', ['userId' => $profile->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3475104340-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>

            <div class="element-container">

                <div id="projectContainer" class=" transition-all">
                    <h2><?php echo e(__('Project List')); ?></h2>
                    <div class="container">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('project-list', ['userId' => $profile->user_id, 'context' => 'other-bloggers-projects']);

$__html = app('livewire')->mount($__name, $__params, 'lw-3475104340-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>

                <div id="commentContainer" class="hidden transition-all">
                    <h2><?php echo e(__('Comment List')); ?></h2>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('comments-display', ['userId' => $profile->user_id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3475104340-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>

            </div>

        </div>
    </div>


</div>

<script>
    Livewire.on('projectsClicked', () => {
        const projectDiv = document.getElementById("projectContainer");
        const commentDiv = document.getElementById("commentContainer");

        projectDiv.style.display = "";
        commentDiv.style.display = "none";
    });

    Livewire.on('commentsClicked', () => {
        const projectDiv = document.getElementById("projectContainer");
        const commentDiv = document.getElementById("commentContainer");

        commentDiv.style.display = "";
        projectDiv.style.display = "none";
        commentDiv.classList.remove("hidden");
    });
</script>
<?php /**PATH /var/www/html/resources/views/livewire/blogger-details.blade.php ENDPATH**/ ?>