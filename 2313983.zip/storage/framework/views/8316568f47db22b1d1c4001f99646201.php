<div>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="page-header">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('background-music', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-1244352516-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <div class="page-container">

        <div class="element-container">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('display-blogger-profile');

$__html = app('livewire')->mount($__name, $__params, 'lw-1244352516-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>

        <div class="element-container">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('statistics');

$__html = app('livewire')->mount($__name, $__params, 'lw-1244352516-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
        <div class="element-container">

            <div id="projectDiv">
                <div class="flex justify-between items-center ">
                    <h2><?php echo e(__('Project List')); ?></h2>
                    <button id="toggleButton" onclick="toggleCreateProjectForm()" class="create-project-btn bg-[#36c73b]">
                        Create Project
                    </button>
                </div>

                <div class="flex">
                    <div id="projectList" class="w-full  transition-all">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('project-list', ['authOnly' => true, 'context' => 'dashboard']);

$__html = app('livewire')->mount($__name, $__params, 'lw-1244352516-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>

                    <div id="createProjectForm" class=" hidden transition-all">
                        <div class="element-container">
                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('create-project');

$__html = app('livewire')->mount($__name, $__params, 'lw-1244352516-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        </div>
                    </div>
                </div>
            </div>

            <div id="commentDiv" class="hidden">

                <h2><?php echo e(__('Comment List')); ?></h2>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('comments-display', ['userId' => Auth::id()]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1244352516-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
    </div>


    <script>
        Livewire.on('projectsClicked', () => {

            console.log('projectsClicked event received');
            const projectDiv = document.getElementById("projectDiv");
            const commentDiv = document.getElementById("commentDiv");

            projectDiv.style.display = "";
            commentDiv.style.display = "none";
        });

        Livewire.on('commentsClicked', () => {
            console.log('commentsClicked event received');

            const projectDiv = document.getElementById("projectDiv");
            const commentDiv = document.getElementById("commentDiv");

            commentDiv.style.display = "";
            projectDiv.style.display = "none";
            commentDiv.classList.remove("hidden");
        });

        function toggleCreateProjectForm() {
            const form = document.getElementById("createProjectForm");
            const button = document.getElementById("toggleButton");
            const projectList = document.getElementById("projectList");

            if (form.style.display === "none" || form.style.display === "") {
                form.style.display = "block";
                button.textContent = "Close Project Form";
                projectList.classList.add("lg:w-2/3");
                button.classList.remove("bg-[#36c73b]");
                button.classList.add("bg-gray-300");
            } else {
                form.style.display = "none";
                button.textContent = "Create Project";
                projectList.classList.remove("lg:w-2/3");
                button.classList.remove("bg-gray-300");
                button.classList.add("bg-[#36c73b]");
            }
        }
    </script>

</div>
<?php /**PATH /var/www/html/resources/views/livewire/dashboard.blade.php ENDPATH**/ ?>