<div class="w-full h-full">

    <form wire:submit.prevent="submitComment" class="bg-white p-4 rounded shadow-md flex flex-col h-full">
        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <div class="flex-grow">
            <div class="form-group h-full">
                <textarea wire:model="content" class="w-full h-full p-2 border rounded resize-none" placeholder="Add a comment..."></textarea>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>

        <div class="mt-4 text-right">
            <button type="submit" class="submit-btn bg-blue-500 text-white py-2 px-4 rounded">
                Submit Comment
            </button>
        </div>
    </form>
</div>
<?php /**PATH /var/www/html/resources/views/livewire/create-comment.blade.php ENDPATH**/ ?>