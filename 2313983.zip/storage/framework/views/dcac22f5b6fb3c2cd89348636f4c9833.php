<div>
    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <div class="project-card">

            <div class="project-content">

                <div class="project-list-text-container">
                    <a href="<?php echo e(route('project.details', $project->id)); ?>" class="project-item">
                        <div class="flex justify-between items-center">
                            <h2><?php echo e($project->title); ?></h2>
                            <div>
                                <!--[if BLOCK]><![endif]--><?php if($project->status): ?>
                                    <div class="project-status">
                                        <?php echo e($project->status); ?>

                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                            </div>
                        </div>
                    </a>

                    <div class="blogger-name-container flex justify-between items-center">
                        <div class="flex">
                            <div class="pfp">
                                <div class="pfp-container">
                                    <!--[if BLOCK]><![endif]--><?php if($project->user->bloggerProfile->profile_picture): ?>
                                        <img src="<?php echo e(asset('storage/' . $project->user->bloggerProfile->profile_picture)); ?>"
                                            alt="<?php echo e($project->user->name); ?>'s Profile Picture" class="pfp-container">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('images/default-pfp.gif')); ?>" alt="Default Profile Picture"
                                            class="pfp-container">
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>

                            <div class="blogger-details">
                                <a href="<?php echo e(route('bloggers.profile', $project->user->id)); ?>">
                                    <h3><?php echo e($project->user->name); ?></h3>
                                </a>
                                <p class="project-info">Created At: <?php echo e($project->created_at->diffForHumans()); ?></p>
                            </div>
                        </div>
                        <div>
                            <div class="px-3">
                                
                                <?php echo e($project->likes_count); ?> Likes
                            </div>
                            <div class="px-3">
                                <?php echo e($project->comments_count); ?> Comments

                            </div>
                        </div>
                    </div>


                    <p class="project-info">Description: <?php echo e($project->description); ?></p>
                    <!--[if BLOCK]><![endif]--><?php if($project->categories->isNotEmpty()): ?>
                        <div class="py-3">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $project->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="category"><?php echo e($category->name); ?></span>
                                <!--[if BLOCK]><![endif]--><?php if(!$loop->last): ?>
                                    <span> </span>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div class="project-image-container">
                    <!--[if BLOCK]><![endif]--><?php if($project->featureimage): ?>
                        <img src="<?php echo e(asset('storage/' . $project->featureimage)); ?>"
                            alt="Feature image of <?php echo e($project->title); ?>" class="project-image">
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/default-image.gif')); ?>" alt="Default project image"
                            class="project-image">
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="no-projects">No projects available.</p>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <div class="pagination">
        <?php echo e($projects->links()); ?>

    </div>
</div>
<?php /**PATH /var/www/html/resources/views/livewire/project-list.blade.php ENDPATH**/ ?>